#ifndef WIFI_H
#define WIFI_H

void wifi_start();

#endif